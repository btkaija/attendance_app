import attendance_application

app = attendance_application.AttendanceApplication()